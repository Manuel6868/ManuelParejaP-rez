import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

public class Main {

    private static final double IVA_RATE = 0.21; // IVA del 21%
    private static double ingresosTotales = 0.0;
    private static int plateaVendidas = 0, butacasVendidas = 0, anfiteatroVendidas = 0;
    private static int capacidadPlatea = 140, capacidadButacas = 200, capacidadAnfiteatro = 200;

    // Fechas de los eventos
    private static final LocalDate fechaEvento1 = LocalDate.of(2024, 11, 20);
    private static final LocalDate fechaEvento2 = LocalDate.of(2024, 11, 28);
    private static final LocalDate fechaEvento3 = LocalDate.of(2024, 12, 6);

    // Nombres de los eventos
    private static final String nombreEvento1 = "Las criadas";
    private static final String nombreEvento2 = "II Concierto de Otoño";
    private static final String nombreEvento3 = "Concierto de Jazz";

    // Descuentos de los eventos
    private static final double descuentoEvento1 = 0.05;
    private static final double descuentoEvento2 = 0.07;
    private static final double descuentoEvento3 = 0.03;

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        boolean continuar = true;

        while (continuar) {
            System.out.println("\n--- Menú Principal ---");
            System.out.println("a. Vender entradas para un evento");
            System.out.println("b. Consultar estado de las entradas");
            System.out.println("c. Mostrar días restantes y descuento anticipado");
            System.out.print("Seleccione una opción: ");
            char opcion = s.nextLine().toLowerCase().charAt(0);

            switch (opcion) {
                case 'a' -> venderEntradas(s);
                case 'b' -> estadoEntradas();
                case 'c' -> mostrarDiasYDescuento();
                default -> System.out.println("Opción no válida. Inténtelo de nuevo.");
            }
        }
        s.close();
    }

    // Función para vender entradas
    private static void venderEntradas(Scanner s) {
        System.out.println("\n--- Venta de Entradas ---");
        System.out.println("""
                Seleccione la actuación:
                1. Las criadas (20/11/2024)
                2. II Concierto de Otoño (28/11/2024)
                3. Concierto de Jazz (06/12/2024)
                Introduce la opción deseada:\s
                """);
        int option = Integer.parseInt(s.nextLine());

        // Asignación de precios y descuentos por evento
        double precioPlatea = 0, precioButacas = 0, precioAnfiteatro = 0;
        double descuento = 0;
        LocalDate fechaEvento = null;

        switch (option) {
            case 1 -> {
                System.out.println("Has seleccionado 'Las criadas'");
                precioPlatea = 17;
                precioButacas = 20;
                precioAnfiteatro = 13;
                descuento = descuentoEvento1;
                fechaEvento = fechaEvento1;
            }
            case 2 -> {
                System.out.println("Has seleccionado 'II Concierto de Otoño'");
                precioPlatea = 12;
                precioButacas = 15;
                precioAnfiteatro = 8;
                descuento = descuentoEvento2;
                fechaEvento = fechaEvento2;
            }
            case 3 -> {
                System.out.println("Has seleccionado 'Concierto de Jazz'");
                precioPlatea = 20;
                precioButacas = 25;
                precioAnfiteatro = 15;
                descuento = descuentoEvento3;
                fechaEvento = fechaEvento3;
            }
            default -> {
                System.out.println("Opción inválida. Saliendo de la venta de entradas.");
                return;
            }
        }

        System.out.print("¿Desea comprar entradas? (Si/No): ");
        boolean respuesta = s.nextLine().equalsIgnoreCase("Si");

        if (respuesta) {
            System.out.println("""
                    Seleccione el tipo de asiento:
                    1. Platea
                    2. Butacas
                    3. Anfiteatro
                    """);
            int seatOption = Integer.parseInt(s.nextLine());
            double precioEntrada = 0;
            int capacidadActual = 0;
            int entradasVendidasActual = 0;

            switch (seatOption) {
                case 1 -> {
                    precioEntrada = precioPlatea;
                    capacidadActual = capacidadPlatea;
                    entradasVendidasActual = plateaVendidas;
                    System.out.println("Has seleccionado asiento en Platea.");
                }
                case 2 -> {
                    precioEntrada = precioButacas;
                    capacidadActual = capacidadButacas;
                    entradasVendidasActual = butacasVendidas;
                    System.out.println("Has seleccionado asiento en Butacas.");
                }
                case 3 -> {
                    precioEntrada = precioAnfiteatro;
                    capacidadActual = capacidadAnfiteatro;
                    entradasVendidasActual = anfiteatroVendidas;
                    System.out.println("Has seleccionado asiento en Anfiteatro.");
                }
                default -> {
                    System.out.println("Opción de asiento inválida. Saliendo de la venta de entradas.");
                    return;
                }
            }

            //  descuento
            LocalDate fechaHoy = LocalDate.now();
            long diasRestantes = ChronoUnit.DAYS.between(fechaHoy, fechaEvento);
            if (diasRestantes > 7) {
                precioEntrada -= precioEntrada * descuento;
                System.out.println("Descuento anticipado aplicado. Precio con descuento: " + precioEntrada + "€");
            }

            //  cantidad de entradas y actualizar ingresos
            System.out.print("¿Cuántas entradas quieres?: ");
            int entradas = Integer.parseInt(s.nextLine());

            if (entradas > capacidadActual - entradasVendidasActual) {
                System.out.println("No hay suficientes entradas disponibles.");
                return;
            }

            // Actualizar la cantidad vendida para el tipo de asiento específico
            switch (seatOption) {
                case 1 -> plateaVendidas += entradas;
                case 2 -> butacasVendidas += entradas;
                case 3 -> anfiteatroVendidas += entradas;
            }

            // , el IVA y el total con IVA
            double totalSinIVA = entradas * precioEntrada;
            double iva = totalSinIVA * IVA_RATE;
            double totalConIVA = totalSinIVA + iva;
            ingresosTotales += totalConIVA;

            System.out.printf("Has solicitado %d entradas.%n", entradas);
            System.out.printf("Precio sin IVA: %.2f€%n", totalSinIVA);
            System.out.printf("IVA (21%%): %.2f€%n", iva);
            System.out.printf("Total con IVA: %.2f€%n", totalConIVA);

            // el pago y el cambio
            System.out.print("Introduce la cantidad con la que vas a pagar: ");
            double pago = Double.parseDouble(s.nextLine());

            if (pago >= totalConIVA) {
                double cambio = pago - totalConIVA;
                System.out.printf("Pago recibido: %.2f€. Su cambio es: %.2f€%n", pago, cambio);
                darCambio(cambio);
            } else {
                System.out.println("El monto ingresado no es suficiente. Venta cancelada.");
                switch (seatOption) {
                    case 1 -> plateaVendidas -= entradas;
                    case 2 -> butacasVendidas -= entradas;
                    case 3 -> anfiteatroVendidas -= entradas;
                }
            }
        } else {
            System.out.println("No se han seleccionado entradas.");
        }

    }

    // cambio en monedas
    private static void darCambio(double cambio) {
        int cambioEnCentimos = (int) Math.round(cambio * 100);

        int monedas5000 = cambioEnCentimos / 5000;
        cambioEnCentimos %= 5000;

        int monedas2000 = cambioEnCentimos / 2000;
        cambioEnCentimos %= 2000;

        int monedas1000 = cambioEnCentimos / 1000;
        cambioEnCentimos %= 1000;

        int monedas500 = cambioEnCentimos / 500;
        cambioEnCentimos %= 500;

        int monedas200 = cambioEnCentimos / 200;
        cambioEnCentimos %= 200;

        int monedas100 = cambioEnCentimos / 100;
        cambioEnCentimos %= 100;

        int monedas50 = cambioEnCentimos / 50;
        cambioEnCentimos %= 50;

        int monedas20 = cambioEnCentimos / 20;
        cambioEnCentimos %= 20;

        int monedas10 = cambioEnCentimos / 10;
        cambioEnCentimos %= 10;

        int monedas5 = cambioEnCentimos / 5;
        cambioEnCentimos %= 5;

        int monedas2 = cambioEnCentimos / 2;
        cambioEnCentimos %= 2;

        int monedas1 = cambioEnCentimos;

        System.out.println("Cambio desglosado en monedas:");
        if (monedas5000 > 0) System.out.println(monedas5000 + " billete(s) de 50€");
        if (monedas2000 > 0) System.out.println(monedas2000 + " billete(s) de 20€");
        if (monedas1000 > 0) System.out.println(monedas1000 + " billete(s) de 10€");
        if (monedas500 > 0) System.out.println(monedas500 + " billete(s) de 5€");
        if (monedas200 > 0) System.out.println(monedas200 + " moneda(s) de 2€");
        if (monedas100 > 0) System.out.println(monedas100 + " moneda(s) de 1€");
        if (monedas50 > 0) System.out.println(monedas50 + " moneda(s) de 0.50€");
        if (monedas20 > 0) System.out.println(monedas20 + " moneda(s) de 0.20€");
        if (monedas10 > 0) System.out.println(monedas10 + " moneda(s) de 0.10€");
        if (monedas5 > 0) System.out.println(monedas5 + " moneda(s) de 0.05€");
        if (monedas2 > 0) System.out.println(monedas2 + " moneda(s) de 0.02€");
        if (monedas1 > 0) System.out.println(monedas1 + " moneda(s) de 0.01€");

    }


    //   estado de las entradas
    private static void estadoEntradas() {
        System.out.println("\n--- Estado de las Entradas ---");
        System.out.println("Tipo de Asiento\tEntradas Vendidas\tEntradas Libres");
        System.out.println("Platea\t\t" + plateaVendidas + "\t\t" + (capacidadPlatea - plateaVendidas));
        System.out.println("Butacas\t\t" + butacasVendidas + "\t\t" + (capacidadButacas - butacasVendidas));
        System.out.println("Anfiteatro\t" + anfiteatroVendidas + "\t\t" + (capacidadAnfiteatro - anfiteatroVendidas));
    }

    //  días restantes y descuento anticipado
    private static void mostrarDiasYDescuento() {
        LocalDate fechaHoy = LocalDate.now();

        long diasRestantes1 = ChronoUnit.DAYS.between(fechaHoy, fechaEvento1);
        System.out.println(nombreEvento1 + ":");
        System.out.println("  Días restantes: " + diasRestantes1);
        System.out.println("  Descuento anticipado disponible: " + ((diasRestantes1 > 7) ? (int) (descuentoEvento1 * 100) + "%" : "No disponible"));

        long diasRestantes2 = ChronoUnit.DAYS.between(fechaHoy, fechaEvento2);
        System.out.println(nombreEvento2 + ":");
        System.out.println("  Días restantes: " + diasRestantes2);
        System.out.println("  Descuento anticipado disponible: " + ((diasRestantes2 > 7) ? (int) (descuentoEvento2 * 100) + "%" : "No disponible"));

        long diasRestantes3 = ChronoUnit.DAYS.between(fechaHoy, fechaEvento3);
        System.out.println(nombreEvento3 + ":");
        System.out.println("  Días restantes: " + diasRestantes3);
        System.out.println("  Descuento anticipado disponible: " + ((diasRestantes3 > 7) ? (int) (descuentoEvento3 * 100) + "%" : "No disponible"));
    }
}
